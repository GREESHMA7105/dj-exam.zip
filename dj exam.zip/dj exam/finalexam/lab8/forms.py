from django import forms
from .models import Project
class ProjectForm(forms.ModelForm):
    class Meta:
        model=Project
        fields=['topic','languages','duration']
        widgets={
            'topic':forms.TextInput(),
            'languages':forms.TextInput(),
            'duration':forms.TimeInput(),
        }