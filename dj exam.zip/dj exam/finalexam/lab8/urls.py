from django.urls import path
from . import views
urlpatterns=[
    path("indexx/",views.index,name="indexx"),
    path("register_project/",views.register_project,name="register_project"),
    path("projectlist/<int:project_id>/",views.projectlist,name="projectlist"),
]