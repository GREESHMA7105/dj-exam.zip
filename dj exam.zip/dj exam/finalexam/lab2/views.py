from django.shortcuts import render
from django.http import HttpResponse
from datetime import datetime,timedelta

def lab2(request):
    cur=datetime.now()
    delta=timedelta(hours=+4)
    fut=cur+delta
    past=cur-delta
    html="<html><body><b>Current DateTime is:</b>%s</body></html>"%cur
    html1="<br><b>future:<b>%s"%fut
    html2=html+html1+"<br><b>Past:<b>%s</body></html>"%past
    return HttpResponse(html2)
    