from django.urls import path
from . import views
urlpatterns = [
    path('lab1/',views.lab1,name='lab1')
]
