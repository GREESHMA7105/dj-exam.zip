from django.shortcuts import render

from django.http import HttpResponse
from datetime import datetime
def lab1(request):
    cur=datetime.now()
    html="<html><body><b>Current Date Time is :</b>%s</body></html>"%cur
    return HttpResponse(html)
    
