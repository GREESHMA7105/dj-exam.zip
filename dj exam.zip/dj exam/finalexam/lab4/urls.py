from django.urls import path
from . import views
urlpatterns = [
    path('lab4/',views.lab4,name=('lab4')),
    path('about/',views.about,name=('about')),
    path('contact/',views.contact,name=('contact'))
]
