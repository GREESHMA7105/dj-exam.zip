from django.urls import path
from . import views
urlpatterns = [
    path('lab3/',views.lab3,name='lab3')
]
