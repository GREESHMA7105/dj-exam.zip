from django.shortcuts import render

def lab3(request):
    fruits=['A','B','C','D']
    students=['P','Q','R','S']
    context={
        'fruits':fruits,
        'students':students,
    }
    return render(request,'list.html',context)